Plik kompilowałem przez: g++ Piramidy.cpp -L/usr/X11R6/lib -lm -lpthread -lX11
Zamieściłem też plik CImg.h który powinien być w folderze z plikiem .cpp, jest to biblioteka do rysowania.
U mnie była też potrzeba doinstalowania graphicsmagick: sudo apt-get install graphicsmagick
Zamieściłem też przykładowy wynikowy obrazek wzorowany na tym z treści zadania. 
